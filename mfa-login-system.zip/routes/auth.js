const express = require("express");
const { register, login, enableMFA, verifyMFA } = require("../controllers/authController");

const router = express.Router();

router.post("/register", register);
router.post("/login", login);
router.post("/enable-mfa", enableMFA);
router.post("/verify-mfa", verifyMFA);

module.exports = router;