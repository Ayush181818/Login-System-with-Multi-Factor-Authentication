require("dotenv").config();
const express = require("express");
const session = require("express-session");
const { authenticator } = require("otplib");
const path = require("path");

const app = express();
const users = [];

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.use(express.urlencoded({ extended: true }));
app.use(express.static("public"));
app.use(session({
  secret: 'testsecret',
  resave: false,
  saveUninitialized: true
}));

app.get("/", (req, res) => {
  res.redirect("/login");
});

app.get("/login", (req, res) => {
  res.render("login");
});

app.get("/register", (req, res) => {
  res.render("register");
});

app.post("/register", (req, res) => {
  const { name, email, password } = req.body;

  const secret = authenticator.generateSecret();
  const otp = authenticator.generate(secret);

  const newUser = { name, email, password, otpSecret: secret };
  users.push(newUser);
  req.session.user = newUser;

  console.log("Registration OTP:", otp);

  res.render("verify", { otp });
});

app.post("/login", (req, res) => {
  const { email, password } = req.body;
  const user = users.find(u => u.email === email && u.password === password);

  if (!user) {
    return res.send("<h2>❌ Invalid credentials. Please try again.</h2>");
  }

  const otp = authenticator.generate(user.otpSecret);
  req.session.user = user;

  console.log("Login OTP:", otp);

  res.render("verify", { otp });
});

app.post("/verify-otp", (req, res) => {
  const { otp } = req.body;
  const user = req.session.user;

  if (!user) {
    return res.send("Session expired. Please register or login again.");
  }

  const isValid = authenticator.check(otp, user.otpSecret);
  if (isValid) {
    res.send(`<h2>✅ OTP Verified! Welcome, ${user.name}!</h2>`);
  } else {
    res.send("<h2>❌ Invalid OTP. Please try again.</h2>");
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(\`Server running at http://localhost:\${PORT}\`));
